<?php

namespace App\Filament\Bendahara\Resources\ValidasiPengeluaranResource\Pages;

use App\Filament\Bendahara\Resources\ValidasiPengeluaranResource;
use Filament\Resources\Pages\ListRecords;

class ListValidasiPengeluaran extends ListRecords
{
    protected static string $resource = ValidasiPengeluaranResource::class;
}