<?php

namespace App\Filament\Bendahara\Resources\ValidasiTindakanResource\Pages;

use App\Filament\Bendahara\Resources\ValidasiTindakanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateValidasiTindakan extends CreateRecord
{
    protected static string $resource = ValidasiTindakanResource::class;
}