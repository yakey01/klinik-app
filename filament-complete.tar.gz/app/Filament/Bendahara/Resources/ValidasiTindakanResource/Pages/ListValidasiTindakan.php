<?php

namespace App\Filament\Bendahara\Resources\ValidasiTindakanResource\Pages;

use App\Filament\Bendahara\Resources\ValidasiTindakanResource;
use Filament\Resources\Pages\ListRecords;

class ListValidasiTindakan extends ListRecords
{
    protected static string $resource = ValidasiTindakanResource::class;
}