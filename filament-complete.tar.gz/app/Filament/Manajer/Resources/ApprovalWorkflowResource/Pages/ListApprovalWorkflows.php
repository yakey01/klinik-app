<?php

namespace App\Filament\Manajer\Resources\ApprovalWorkflowResource\Pages;

use App\Filament\Manajer\Resources\ApprovalWorkflowResource;
use Filament\Resources\Pages\ListRecords;

class ListApprovalWorkflows extends ListRecords
{
    protected static string $resource = ApprovalWorkflowResource::class;
}