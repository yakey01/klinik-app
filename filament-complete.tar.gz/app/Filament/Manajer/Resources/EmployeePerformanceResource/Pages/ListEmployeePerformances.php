<?php

namespace App\Filament\Manajer\Resources\EmployeePerformanceResource\Pages;

use App\Filament\Manajer\Resources\EmployeePerformanceResource;
use Filament\Resources\Pages\ListRecords;

class ListEmployeePerformances extends ListRecords
{
    protected static string $resource = EmployeePerformanceResource::class;
}