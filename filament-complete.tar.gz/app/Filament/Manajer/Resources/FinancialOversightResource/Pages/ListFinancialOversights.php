<?php

namespace App\Filament\Manajer\Resources\FinancialOversightResource\Pages;

use App\Filament\Manajer\Resources\FinancialOversightResource;
use Filament\Resources\Pages\ListRecords;

class ListFinancialOversights extends ListRecords
{
    protected static string $resource = FinancialOversightResource::class;
}