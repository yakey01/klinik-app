<?php

namespace App\Filament\Manajer\Resources\LeaveApprovalResource\Pages;

use App\Filament\Manajer\Resources\LeaveApprovalResource;
use Filament\Resources\Pages\ListRecords;

class ListLeaveApprovals extends ListRecords
{
    protected static string $resource = LeaveApprovalResource::class;
}