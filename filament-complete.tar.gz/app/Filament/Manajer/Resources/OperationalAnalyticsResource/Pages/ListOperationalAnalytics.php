<?php

namespace App\Filament\Manajer\Resources\OperationalAnalyticsResource\Pages;

use App\Filament\Manajer\Resources\OperationalAnalyticsResource;
use Filament\Resources\Pages\ListRecords;

class ListOperationalAnalytics extends ListRecords
{
    protected static string $resource = OperationalAnalyticsResource::class;
}