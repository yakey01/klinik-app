<?php

namespace App\Filament\Manajer\Resources\StrategicPlanningResource\Pages;

use App\Filament\Manajer\Resources\StrategicPlanningResource;
use Filament\Resources\Pages\ListRecords;

class ListStrategicPlannings extends ListRecords
{
    protected static string $resource = StrategicPlanningResource::class;
}