<?php

namespace App\Filament\Paramedis\Resources\JaspelResource\Pages;

use App\Filament\Paramedis\Resources\JaspelResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateJaspel extends CreateRecord
{
    protected static string $resource = JaspelResource::class;
    
    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
