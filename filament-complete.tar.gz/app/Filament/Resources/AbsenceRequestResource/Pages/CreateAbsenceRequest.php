<?php

namespace App\Filament\Resources\AbsenceRequestResource\Pages;

use App\Filament\Resources\AbsenceRequestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAbsenceRequest extends CreateRecord
{
    protected static string $resource = AbsenceRequestResource::class;
    
    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
