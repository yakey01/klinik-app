<?php

namespace App\Filament\Resources\ValidasiLokasiResource\Pages;

use App\Filament\Resources\ValidasiLokasiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateValidasiLokasi extends CreateRecord
{
    protected static string $resource = ValidasiLokasiResource::class;
    
    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
